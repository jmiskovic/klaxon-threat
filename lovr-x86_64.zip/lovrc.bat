lovr --console %*
